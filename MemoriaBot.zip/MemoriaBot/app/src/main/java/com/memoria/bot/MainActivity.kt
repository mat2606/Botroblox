package com.memoria.bot

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 80, 48, 48)
        }

        col.addView(TextView(this).apply {
            textSize = 16f
            text = "Memoria Bot\n\n" +
                "1) Toque em \"Ativar acessibilidade\", procure \"Memoria Bot\" e ligue.\n" +
                "2) Toque em \"Permitir captura de tela\" e aceite.\n" +
                "3) Abra o Roblox na horizontal. Vai aparecer um painel pequeno na lateral esquerda.\n" +
                "4) No painel: \"Cartas\" (com o jogo aberto) e \"Botão E\" (com o jogo fechado) para calibrar, depois \"Iniciar\".\n\n" +
                "Se o Android bloquear a acessibilidade (\"configuração restrita\"), vá em Config > Apps > Memoria Bot > menu ⋮ > Permitir configurações restritas."
        })

        col.addView(Button(this).apply {
            text = "1) Ativar acessibilidade"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        col.addView(Button(this).apply {
            text = "2) Permitir captura de tela"
            setOnClickListener {
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                @Suppress("DEPRECATION")
                startActivityForResult(mpm.createScreenCaptureIntent(), 1)
            }
        })

        setContentView(ScrollView(this).apply {
            addView(col, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            Toast.makeText(this, "Captura liberada", Toast.LENGTH_SHORT).show()
        }
    }
}
