package com.memoria.bot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager

class CaptureService : Service() {

    companion object {
        @Volatile
        var instance: CaptureService? = null
    }

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var w = 0
    private var h = 0

    @Volatile
    private var last: Bitmap? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("cap", "Captura", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "cap")
            .setContentTitle("Memoria Bot")
            .setContentText("Capturando a tela")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra("data", Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra("data")
        }
        if (data != null) {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mpm.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    instance = null
                }
            }, Handler(Looper.getMainLooper()))
            instance = this
        }
        return START_NOT_STICKY
    }

    /** (Re)cria a captura com o tamanho atual da tela (ex.: depois de girar). */
    @Synchronized
    fun prepare(): Boolean {
        val p = projection ?: return false
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        if (vd != null && dm.widthPixels == w && dm.heightPixels == h) return true

        w = dm.widthPixels
        h = dm.heightPixels
        reader?.close()
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        if (vd == null) {
            vd = p.createVirtualDisplay(
                "memoria-cap", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                r.surface, null, null
            )
        } else {
            vd!!.resize(w, h, dm.densityDpi)
            vd!!.setSurface(r.surface)
        }
        last = null
        return true
    }

    @Synchronized
    fun frame(): Bitmap? {
        val r = reader ?: return last
        val img = try {
            r.acquireLatestImage()
        } catch (e: Exception) {
            null
        }
        if (img != null) {
            try {
                val pl = img.planes[0]
                val bw = pl.rowStride / pl.pixelStride
                val bmp = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(pl.buffer)
                last = if (bw == img.width) bmp else Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
            } finally {
                img.close()
            }
        }
        return last
    }

    override fun onDestroy() {
        vd?.release()
        reader?.close()
        projection?.stop()
        instance = null
        super.onDestroy()
    }
}
