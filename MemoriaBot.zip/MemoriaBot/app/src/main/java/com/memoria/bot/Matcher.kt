package com.memoria.bot

import android.graphics.Bitmap
import kotlin.math.abs

object Matcher {
    const val CW = 100
    const val CH = 156

    /** Mesmo tratamento do script do PC: 100x156, miolo, 35x58. */
    fun norm(src: Bitmap): FloatArray {
        val scaled = Bitmap.createScaledBitmap(src, CW, CH, true)
        val inner = Bitmap.createBitmap(scaled, 15, 20, CW - 30, CH - 40)
        val small = Bitmap.createScaledBitmap(inner, 35, 58, true)
        val px = IntArray(35 * 58)
        small.getPixels(px, 0, 35, 0, 0, 35, 58)
        val out = FloatArray(35 * 58 * 3)
        for (i in px.indices) {
            val p = px[i]
            out[i * 3] = ((p shr 16) and 0xFF).toFloat()
            out[i * 3 + 1] = ((p shr 8) and 0xFF).toFloat()
            out[i * 3 + 2] = (p and 0xFF).toFloat()
        }
        return out
    }

    fun sig(frame: Bitmap, cx: Float, cy: Float, w: Float, h: Float): FloatArray {
        val l = (cx - w / 2f).toInt().coerceIn(0, frame.width - 2)
        val t = (cy - h / 2f).toInt().coerceIn(0, frame.height - 2)
        val wi = w.toInt().coerceIn(1, frame.width - l)
        val hi = h.toInt().coerceIn(1, frame.height - t)
        return norm(Bitmap.createBitmap(frame, l, t, wi, hi))
    }

    fun diff(a: FloatArray, b: FloatArray): Float {
        var s = 0f
        for (i in a.indices) s += abs(a[i] - b[i])
        return s / a.size
    }
}
