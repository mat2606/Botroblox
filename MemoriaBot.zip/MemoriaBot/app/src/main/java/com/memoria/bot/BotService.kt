package com.memoria.bot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class BotService : AccessibilityService(), Bot.Host {

    companion object {
        @Volatile
        var instance: BotService? = null

        val ARQUIVOS = mapOf(
            "coroa" to "coroa.png",
            "fada dem" to "fadadem.png",
            "fada lua" to "fadalua.png",
            "rosa" to "rosa.png",
            "fada negra" to "fadanegra.png",
            "fada flor" to "fadaflor.png",
            "calice" to "calice.png",
            "lua" to "lua.png"
        )
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var status: TextView? = null
    private var calibView: View? = null

    @Volatile
    private var running = false
    private var thread: Thread? = null
    private var refs: Map<String, FloatArray>? = null

    private val prefs by lazy { getSharedPreferences("cfg", Context.MODE_PRIVATE) }

    // ------------------------------------------------------------ ciclo ----
    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        running = false
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { calibView?.let { wm.removeView(it) } } catch (_: Exception) {}
        instance = null
        super.onDestroy()
    }

    // --------------------------------------------------------- Bot.Host ----
    override fun frame() = CaptureService.instance?.frame()

    override fun tap(x: Float, y: Float) = gesture(x, y, 90)

    override fun hold(x: Float, y: Float, ms: Long) = gesture(x, y, ms)

    override fun log(s: String) = setStatus(s)

    override fun isRunning() = running

    private fun gesture(x: Float, y: Float, ms: Long) {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, ms))
            .build()
        val latch = CountDownLatch(1)
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        if (ok) latch.await(ms + 3000, TimeUnit.MILLISECONDS)
    }

    // ------------------------------------------------------------- UI ------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun setStatus(s: String) {
        main.post { status?.text = s }
    }

    private fun showPanel() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(170, 0, 0, 0))
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val st = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 10f
            text = "Pronto"
            maxWidth = dp(220)
        }
        status = st
        col.addView(st)

        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t
            textSize = 11f
            isAllCaps = false
            minHeight = 0
            minimumHeight = dp(34)
            setOnClickListener { f() }
        }

        col.addView(btn("Cartas") { startCalib(listOf(
            "Toque no CENTRO da carta do canto SUPERIOR ESQUERDO",
            "Toque no CENTRO da carta do canto INFERIOR DIREITO")) { pts ->
            prefs.edit()
                .putFloat("x1", pts[0].x).putFloat("y1", pts[0].y)
                .putFloat("xn", pts[1].x).putFloat("yn", pts[1].y)
                .putBoolean("calCartas", true).apply()
            setStatus("Cartas calibradas")
        } })

        col.addView(btn("Botão E") { startCalib(listOf(
            "Toque no botão E (Jogar minijogo)")) { pts ->
            prefs.edit()
                .putFloat("ex", pts[0].x).putFloat("ey", pts[0].y)
                .putBoolean("calE", true).apply()
            setStatus("Botão E calibrado")
        } })

        col.addView(btn("Iniciar") { start() })
        col.addView(btn("Parar") {
            running = false
            setStatus("Parando...")
        })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL }

        wm.addView(col, lp)
        panel = col
    }

    private inner class CalibView(
        ctx: Context,
        val steps: List<String>,
        val onDone: (List<PointF>) -> Unit
    ) : View(ctx) {
        private val pts = mutableListOf<PointF>()
        private val tp = Paint().apply { color = Color.WHITE; textSize = 48f; isAntiAlias = true }
        private val dot = Paint().apply { color = Color.RED; isAntiAlias = true }

        override fun onDraw(c: Canvas) {
            c.drawColor(Color.argb(90, 0, 0, 0))
            val msg = if (pts.size < steps.size) steps[pts.size] else "Pronto"
            c.drawText(msg, 140f, 120f, tp)
            for (p in pts) c.drawCircle(p.x, p.y, 16f, dot)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.action == MotionEvent.ACTION_UP) {
                pts.add(PointF(e.rawX, e.rawY))
                invalidate()
                if (pts.size == steps.size) onDone(pts.toList())
            }
            return true
        }
    }

    private fun startCalib(steps: List<String>, save: (List<PointF>) -> Unit) {
        if (calibView != null) return
        val v = CalibView(this, steps) { pts ->
            main.post {
                save(pts)
                try { calibView?.let { wm.removeView(it) } } catch (_: Exception) {}
                calibView = null
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(v, lp)
        calibView = v
    }

    // ------------------------------------------------------------- bot ------
    private fun loadCfg(fw: Float, fh: Float): Cfg {
        val w = maxOf(fw, fh)
        val h = minOf(fw, fh)
        // Valores padrão medidos nos prints do celular (1600x717), em proporção da tela
        return Cfg(
            x1 = prefs.getFloat("x1", 636f / 1600f * w),
            y1 = prefs.getFloat("y1", 203f / 717f * h),
            xn = prefs.getFloat("xn", 964f / 1600f * w),
            yn = prefs.getFloat("yn", 589f / 717f * h),
            ex = prefs.getFloat("ex", 684f / 1600f * w),
            ey = prefs.getFloat("ey", 343f / 717f * h),
            cx = 800f / 1600f * w,
            cy = 667f / 717f * h
        )
    }

    private fun loadRefs(): Map<String, FloatArray> {
        refs?.let { return it }
        val m = ARQUIVOS.mapValues { (_, file) ->
            val bmp = assets.open(file).use { BitmapFactory.decodeStream(it) }
            Matcher.norm(bmp)
        }
        refs = m
        return m
    }

    private fun salvarDebug(bmp: Bitmap) {
        try {
            val v = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "memoria_frame.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/MemoriaBot")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            }
        } catch (_: Exception) {
        }
    }

    private fun start() {
        if (running) return
        val cap = CaptureService.instance
        if (cap == null) {
            setStatus("Falta liberar captura (abra o app)")
            return
        }
        running = true
        thread = Thread {
            try {
                cap.prepare()
                var tries = 0
                while (cap.frame() == null && tries < 30) {
                    Thread.sleep(100); tries++
                }
                val f0 = cap.frame()
                if (f0 == null) {
                    setStatus("Sem imagem da tela")
                } else if (f0.height > f0.width) {
                    setStatus("Tela na vertical: abra o Roblox na horizontal e toque Iniciar")
                } else {
                    salvarDebug(f0)
                    Bot(this, loadCfg(f0.width.toFloat(), f0.height.toFloat())).run()
                }
            } catch (e: Exception) {
                setStatus("Erro: ${e.message}")
            } finally {
                running = false
            }
        }.also { it.start() }
    }
}
