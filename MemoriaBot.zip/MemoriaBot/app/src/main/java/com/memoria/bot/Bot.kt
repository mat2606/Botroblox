package com.memoria.bot

import android.graphics.Bitmap
import android.util.Log

data class Cfg(
    val x1: Float, val y1: Float,   // centro da carta superior esquerda
    val xn: Float, val yn: Float,   // centro da carta inferior direita
    val ex: Float, val ey: Float,   // botão para entrar no minijogo
    val cx: Float, val cy: Float    // onde tocar para fechar o prêmio
)

class Bot(
    private val h: Host,
    private val c: Cfg
) {
    interface Host {
        fun frame(): Bitmap?
        fun tap(x: Float, y: Float)
        fun hold(x: Float, y: Float, ms: Long)
        fun log(s: String)
        fun isRunning(): Boolean
    }

    class Stop : RuntimeException()

    // Cartas parecidas = mesma figura. Veja os números no painel para ajustar.
    private val sim = 14f        // diferença MENOR que isso = mesma figura
    private val face = 25f       // diferença do verso MAIOR que isso = carta virada
    private val estavel = 8f     // duas leituras parecidas = animação terminou

    private val dx = (c.xn - c.x1) / 3f
    private val dy = (c.yn - c.y1) / 3f
    private val cardW = dx * 0.67f
    private val cardH = dy * 0.87f

    private val pos: List<Pair<Float, Float>> = buildList {
        for (col in 0 until 4) for (row in 0 until 4) {
            add(Pair(c.x1 + dx * col, c.y1 + dy * row))
        }
    }

    private var verso: FloatArray = FloatArray(0)
    private val resolvidas = mutableSetOf<Int>()
    private val vistas = mutableMapOf<Int, FloatArray>()
    private val falhas = mutableMapOf<Int, Int>()
    private val puladas = mutableSetOf<Int>()

    private fun say(s: String) {
        Log.d("MemoriaBot", s)
        h.log(s)
    }

    private fun pause(ms: Long) {
        var t = 0L
        while (t < ms) {
            if (!h.isRunning()) throw Stop()
            Thread.sleep(50)
            t += 50
        }
    }

    private fun click(i: Int) {
        h.tap(pos[i].first, pos[i].second)
        pause(250)
    }

    private fun sigAt(i: Int): FloatArray? {
        val f = h.frame() ?: return null
        return Matcher.sig(f, pos[i].first, pos[i].second, cardW, cardH)
    }

    private fun virada(i: Int): Boolean {
        val s = sigAt(i) ?: return false
        return Matcher.diff(s, verso) > face
    }

    /** Espera a carta terminar de virar e devolve a assinatura dela. */
    private fun lerCarta(i: Int, timeoutMs: Long): FloatArray? {
        val fim = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < fim) {
            val s1 = sigAt(i)
            if (s1 != null && Matcher.diff(s1, verso) > face) {
                pause(250)
                val s2 = sigAt(i)
                if (s2 != null && Matcher.diff(s1, s2) < estavel) return s2
            }
            pause(150)
        }
        return null
    }

    /** Toca na carta; se não virou, toca de novo (só se continuar de costas). */
    private fun virarCarta(i: Int): FloatArray? {
        for (t in 0 until 2) {
            click(i)
            val s = lerCarta(i, 1800)
            if (s != null) {
                say("carta $i virou (dif ${"%.0f".format(Matcher.diff(s, verso))})")
                return s
            }
            val atual = sigAt(i)
            if (atual != null && Matcher.diff(atual, verso) > face) return atual
            say("carta $i não virou, tentando de novo")
        }
        return null
    }

    private var diag = ""

    private fun descobrirVerso(): FloatArray? {
        val f = h.frame()
        val tam = if (f != null) "${f.width}x${f.height}" else "sem imagem"
        val sigs = pos.indices.mapNotNull { sigAt(it) }
        if (sigs.size < pos.size) {
            diag = "só ${sigs.size}/16 leituras (tela $tam)"
            return null
        }
        var maior = 0
        for (tol in listOf(sim, 22f, 30f)) {
            var melhor: FloatArray? = null
            var melhorN = 0
            for (s in sigs) {
                val n = sigs.count { Matcher.diff(s, it) < tol }
                if (n > melhorN) {
                    melhor = s
                    melhorN = n
                }
            }
            if (tol == sim) maior = melhorN
            if (melhorN >= 6) {
                say("verso achado: $melhorN/16 (tolerância ${tol.toInt()})")
                return melhor
            }
        }
        val difs = ArrayList<Float>()
        for (x in sigs.indices) for (y in x + 1 until sigs.size) difs.add(Matcher.diff(sigs[x], sigs[y]))
        difs.sort()
        diag = "tela $tam, maior grupo $maior/16, dif mediana ${"%.0f".format(difs[difs.size / 2])}"
        return null
    }

    private fun jogoAberto(): Boolean {
        val n = pos.indices.count { i ->
            val s = sigAt(i)
            s != null && Matcher.diff(s, verso) <= face
        }
        say("Cartas de costas: $n/16")
        return n >= 12
    }

    private fun esperarDesvirar(abertas: List<Int>, maxMs: Long) {
        val fim = System.currentTimeMillis() + maxMs
        while (System.currentTimeMillis() < fim) {
            if (abertas.all { !virada(it) }) return
            pause(200)
        }
    }

    /** Vê quais cartas continuaram viradas (= par achado). */
    private fun fimDoTurno(abertas: List<Int>, esperadoPar: Boolean) {
        if (esperadoPar) pause(900) else esperarDesvirar(abertas, 3000)

        var estados = abertas.map { virada(it) }
        val misto = estados.any { it } && estados.any { !it }
        if ((!esperadoPar && estados.any { it }) || (esperadoPar && misto)) {
            pause(800)
            estados = abertas.map { virada(it) }
        }

        if (esperadoPar && estados.none { it }) {
            say("não era par, descartando leitura")
            abertas.forEach { vistas.remove(it) }
            return
        }
        for ((k, i) in abertas.withIndex()) {
            if (estados[k]) {
                resolvidas.add(i)
                vistas.remove(i)
            }
        }
        if (estados.any { it }) say("par achado! ${resolvidas.size}/16")
    }

    private fun acharPar(): Pair<Int, Int>? {
        val ks = vistas.keys.sorted()
        for (x in ks.indices) {
            for (y in x + 1 until ks.size) {
                if (Matcher.diff(vistas[ks[x]]!!, vistas[ks[y]]!!) < sim) {
                    return Pair(ks[x], ks[y])
                }
            }
        }
        return null
    }

    private fun jogarPartida(prev: FloatArray?): Boolean {
        resolvidas.clear(); vistas.clear(); falhas.clear(); puladas.clear()
        pause(500)
        verso = descobrirVerso() ?: prev
            ?: throw Exception("Sem verso: $diag")

        for (i in pos.indices) if (virada(i)) resolvidas.add(i)
        if (resolvidas.isNotEmpty()) say("Já viradas no início: ${resolvidas.size}")

        for (turno in 0 until 60) {
            if (resolvidas.size >= pos.size) break

            // 1) já conheço um par? clica nele
            val par = acharPar()
            if (par != null) {
                say("par conhecido: ${par.first} e ${par.second}")
                click(par.first)
                pause(200)
                click(par.second)
                fimDoTurno(listOf(par.first, par.second), true)
                continue
            }

            val novas = pos.indices.filter { it !in resolvidas && it !in vistas }
            if (novas.isEmpty()) {
                say("sem cartas novas")
                break
            }

            // 2) primeira carta do turno
            val a = novas[0]
            val sa = virarCarta(a)
            val abertas = mutableListOf(a)
            if (sa == null) {
                falhas[a] = (falhas[a] ?: 0) + 1
                if (falhas[a]!! >= 4) {
                    say("carta $a não lida 4 vezes, pulando")
                    resolvidas.add(a); puladas.add(a)
                }
            }

            // primeira carta já tem par conhecido -> fecha o par
            if (sa != null) {
                val q = vistas.entries.firstOrNull { Matcher.diff(it.value, sa) < sim }?.key
                if (q != null) {
                    say("par de $a já conhecido: $q")
                    vistas[a] = sa
                    click(q)
                    abertas.add(q)
                    fimDoTurno(abertas, true)
                    continue
                }
                vistas[a] = sa
            }

            // 3) segunda carta do turno (sempre abre uma segunda, para fechar o turno)
            val b = novas.drop(1).firstOrNull()
                ?: pos.indices.firstOrNull { it != a && it !in resolvidas }
            if (b == null) break
            val sb = virarCarta(b)
            abertas.add(b)
            if (sb != null) vistas[b] = sb

            val esperadoPar = sa != null && sb != null && Matcher.diff(sa, sb) < sim
            fimDoTurno(abertas, esperadoPar)
        }

        val completa = resolvidas.size >= pos.size && puladas.isEmpty()
        say("Partida ${if (completa) "COMPLETA" else "INCOMPLETA"}: ${resolvidas.size}/16")
        return completa
    }

    private fun fecharPremio() {
        say("Achou todas! Fechando prêmio...")
        pause(3000)
        h.tap(c.cx, c.cy)
        pause(2000)
    }

    private fun reentrar(): Boolean {
        for (t in 1..8) {
            say("Segurando o botão ($t/8)...")
            h.hold(c.ex, c.ey, 1500)
            for (k in 0 until 10) {
                pause(800)
                if (jogoAberto()) {
                    say("Jogo aberto!")
                    pause(800)
                    return true
                }
            }
        }
        return false
    }

    fun run() {
        try {
            var prev: FloatArray? = null
            var rodada = 0
            while (true) {
                rodada++
                say("Rodada $rodada")
                val completa = jogarPartida(prev)
                prev = verso
                if (completa) fecharPremio() else {
                    say("Partida incompleta")
                    pause(2000)
                }
                if (!reentrar()) {
                    say("Não consegui abrir o jogo de novo")
                    break
                }
            }
        } catch (e: Stop) {
            say("Parado")
        } catch (e: Exception) {
            say("Erro: ${e.message}")
            Log.e("MemoriaBot", "erro", e)
        }
    }
}
